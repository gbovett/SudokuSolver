package primary;

import java.util.Arrays;

public class SudokuSolver {
	private int[][] grid;
	private int[][] solved = new int[9][9];

	SudokuSolver(int[][] grid) {
		setGrid(grid);
		solve(this.grid);
	}

	private static boolean isValid(int n, int r, int c, int[][] grid) {
		for (int i = 0; i < 9; i++)
			if (n == grid[r][i] || n == grid[i][c])
				return false;
		r = r / 3 * 3;
		c = c / 3 * 3;
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				if (grid[r + i][c + j] == n)
					return false;
		return true;
	}

	private void solve(int[][] grid) {
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				if (grid[i][j] == 0) {
					for (int n = 1; n < 10; n++) {
						if (isValid(n, i, j, grid)) {
							grid[i][j] = n;
							solve(grid);
							grid[i][j] = 0;
						}
					}
					return;
				}
			}
		}
		for (int i = 0; i < 9; i++) {
			System.arraycopy(grid[i], 0, solved[i], 0, 9);
		}
	}

	private static void printGrid(int[][] grid) {
		for (int[] row : grid)
			System.out.println(Arrays.toString(row));
		System.out.println();
	}
	
	private static String gridToString(int[][] grid) {
		String result = "";
		for (int[] row : grid)
			result += Arrays.toString(row) + "\n";
		return result;
	}

// Getters and Setters

	public void getGrid() {
		printGrid(grid);
	}

	public void setGrid(int[][] grid) {
		this.grid = grid;
	}

	public String getSolvedString() {
		return gridToString(solved);
	}
	
	public void getSolved(){
		printGrid(solved);
	}
}
