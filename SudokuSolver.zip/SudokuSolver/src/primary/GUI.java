package primary;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GUI extends Application {

	public static void main(String[] args) {

		launch(args);
	}

	public void start(Stage stage) {
		SudokuSolver puzzle1 = new SudokuSolver(new int[][] { { 0, 0, 5, 3, 6, 0, 4, 0, 0 },
															  { 9, 6, 2, 0, 0, 4, 0, 7, 0 }, 
															  { 3, 0, 4, 0, 2, 9, 0, 6, 0 },
															  { 8, 2, 0, 9, 4, 0, 0, 1, 3 },
															  { 0, 4, 9, 0, 3, 0, 0, 5, 7 }, 
															  { 0, 3, 0, 2, 0, 0, 9, 8, 4 }, 
															  { 4, 0, 6, 0, 0, 1, 0, 0, 2 },
															  { 2, 0, 0, 6, 9, 3, 0, 4, 5 },
															  { 0, 0, 3, 4, 8, 2, 0, 0, 0 }});
		puzzle1.getGrid();
		puzzle1.getSolved();

		Text text = new Text();
		text.setText(puzzle1.getSolvedString());
		text.setX(90);
		text.setY(50);
		
		// Creating a Group object
		Group root = new Group(text);

		// Creating a scene object
		Scene scene = new Scene(root, 325, 250);

		// Setting title to  the Stage
		stage.setTitle("Solved Puzzle");

		// Adding scene to the stage
		stage.setScene(scene);

		// Displaying the contents of the stage
		stage.show();
	}
}
